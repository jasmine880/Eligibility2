package io.example.eligibiltycheck.dataentity;

import java.util.List;

public class EligibilityCheck {
    private String eligibiltyItem;
    private List<Eligibility> checkInfo;

    public EligibilityCheck() {

    }

    public EligibilityCheck(String eligibiltyItem, List<Eligibility> checkInfo) {
        this.eligibiltyItem = eligibiltyItem;
        this.checkInfo = checkInfo;
    }

    public String getEligibiltyItem() {
        return eligibiltyItem;
    }

    public void setEligibiltyItem(String eligibiltyItem) {
        this.eligibiltyItem = eligibiltyItem;
    }

    public List<Eligibility> getCheckInfo() {
        return checkInfo;
    }

    public void setCheckInfo(List<Eligibility> checkInfo) {
        this.checkInfo = checkInfo;
    }
}
