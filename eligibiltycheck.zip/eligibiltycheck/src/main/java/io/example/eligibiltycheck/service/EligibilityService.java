package io.example.eligibiltycheck.service;

import io.example.eligibiltycheck.dataentity.Eligibility;

public interface EligibilityService {

    public boolean searchForEligibility(String planCode, String versionNum);
}
