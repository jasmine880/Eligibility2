package io.example.eligibiltycheck.dataentity;

import java.util.List;

public class EligibilityEntity {
    private String channel;
    private String policyTerr;
    private String process;
    private List<EligibilityCheck> eligibilitycheck;
    public EligibilityEntity() {

    }

    public EligibilityEntity(String channel, String policyTerr, String process, List<EligibilityCheck> eligibilitycheck) {
        this.channel = channel;
        this.policyTerr = policyTerr;
        this.process = process;
        this.eligibilitycheck = eligibilitycheck;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getPolicyTerr() {
        return policyTerr;
    }

    public void setPolicyTerr(String policyTerr) {
        this.policyTerr = policyTerr;
    }

    public String getProcess() {
        return process;
    }

    public void setProcess(String process) {
        this.process = process;
    }

    public List<EligibilityCheck> getEligibilitycheck() {
        return eligibilitycheck;
    }

    public void setEligibilitycheck(List<EligibilityCheck> eligibilitycheck) {
        this.eligibilitycheck = eligibilitycheck;
    }


}
