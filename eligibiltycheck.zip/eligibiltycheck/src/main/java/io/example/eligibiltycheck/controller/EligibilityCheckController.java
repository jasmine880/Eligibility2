package io.example.eligibiltycheck.controller;

import io.example.eligibiltycheck.dataentity.Eligibility;
import io.example.eligibiltycheck.dataentity.EligibilityEntity;
import io.example.eligibiltycheck.serviceImpl.EligibilityServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class EligibilityCheckController {

    @Autowired
    private Eligibility eligibility;

    @Autowired
    private EligibilityServiceImpl eligibilityServiceImpl;

    @PostMapping("/highlevelcheckEligibility")
    public EligibilityEntity HLEligibilityCheck(@RequestBody EligibilityEntity eligibilityEntity){
        System.out.print("+++++++++++++");
    System.out.print(eligibility.getTxnType());
        if(eligibility.getTxnType().equalsIgnoreCase("FACE_INC" )||
                eligibility.getTxnType().equalsIgnoreCase("CVG_ADD" ) ||
                eligibility.getTxnType().equalsIgnoreCase("CVG_INC" ) ){
            if(eligibility.getTrancheId()=="") {
                if (eligibilityServiceImpl.searchForEligibility(eligibility.getPlanCode(), eligibility.getVersionNum())) {
                    eligibility.setIsEligibile("Y");
                } else {
                    eligibility.setIsEligibile("N");
                }
            }
            else{
                throw new RuntimeException("TrancheId should not be other than blank");
            }
        }
        else{
            throw new RuntimeException("TxnType should be any one of the FACEINC, CVGADD, CVGINC");
        }

        return eligibilityEntity;
    }

    @PostMapping("/checkEligibility")
    public Eligibility EligibilityCheck(@RequestBody Eligibility eligibility){

        if(eligibility.getTxnType().equalsIgnoreCase("FACE_INC" )||
                eligibility.getTxnType().equalsIgnoreCase("CVG_ADD" ) ||
                eligibility.getTxnType().equalsIgnoreCase("CVG_INC" ) ){
            if(eligibility.getTrancheId()=="") {
                if (eligibilityServiceImpl.searchForEligibility(eligibility.getPlanCode(), eligibility.getVersionNum())) {
                    eligibility.setIsEligibile("Y");
                } else {
                    eligibility.setIsEligibile("N");
                }
            }
            else{
                throw new RuntimeException("TrancheId should not be other than blank");
                }
        }
        else{
            throw new RuntimeException("TxnType should be any one of the FACEINC, CVGADD, CVGINC");
        }
        return eligibility;

    }
}
