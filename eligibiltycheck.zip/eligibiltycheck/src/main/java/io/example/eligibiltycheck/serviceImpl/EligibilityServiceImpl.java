package io.example.eligibiltycheck.serviceImpl;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import io.example.eligibiltycheck.service.EligibilityService;
import org.springframework.stereotype.Service;

@Service
public class EligibilityServiceImpl implements EligibilityService {


    @Override
    public boolean searchForEligibility(String planCode, String versionNum) {
        boolean returnCheck = false;
        Multimap<String, String> NameList = ArrayListMultimap.create();

        NameList.put("david", "1");
        NameList.put("cv599", "04");
        NameList.put("jonathan", "4");
        NameList.put("david", "2");

        if(NameList.containsEntry(planCode, versionNum)){
            returnCheck = true;
        }


        return returnCheck;
    }
}
