package io.example.eligibiltycheck.dataentity;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
public class Eligibility {

    private String txnType;
    private String versionNum;
    private String trancheId;
    private String planCode;
    private String isEligibile;


    public Eligibility(){ }

    public Eligibility(String txnType, String versionNum, String trancheId, String planCode, String isEligibile) {
        this.txnType = txnType;
        this.versionNum = versionNum;
        this.trancheId = trancheId;
        this.planCode = planCode;
        this.isEligibile = isEligibile;

    }

    public String getTxnType() {
        return txnType;
    }

    public void setTxnType(String txnType) {
        this.txnType = txnType;
    }

    public String getVersionNum() {
        return versionNum;
    }

    public void setVersionNum(String versionNum) {
        this.versionNum = versionNum;
    }

    public String getTrancheId() {
        return trancheId;
    }

    public void setTrancheId(String trancheId) {
        this.trancheId = trancheId;
    }

    public String getPlanCode() {
        return planCode;
    }

    public void setPlanCode(String planCode) {
        this.planCode = planCode;
    }

    public String getIsEligibile() {
        return isEligibile;
    }

    public void setIsEligibile(String isEligibile) {
        this.isEligibile = isEligibile;
    }

}
